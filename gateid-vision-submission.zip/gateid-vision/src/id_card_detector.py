"""
Custom ID-Card Detector module for GateID Vision.

Loads and runs inference with a trained YOLO model specifically targeting
college ID cards (lanyards, badges, pinned cards). Handles missing weights
gracefully via transparent fallback mode.
"""
from pathlib import Path
from typing import Any, Dict, List, Optional
import logging
import numpy as np

from src.association import BoundingBox, DetectedCard

logger = logging.getLogger(__name__)


class IDCardDetector:
    """
    Detector for college ID cards.

    Important: A general COCO model does not detect college ID cards.
    This detector loads a specifically trained model from a configured path.
    If the model weights are unavailable, it operates in fallback mode without
    fabricating detections.
    """

    def __init__(self, config: Optional[Dict[str, Any]] = None, model_override: Any = None):
        cfg = (config or {}).get("models", {}).get("id_card_detector", {})
        self.model_path = Path(cfg.get("model_path", "models/id_card_detector.pt"))
        self.confidence_threshold = float(cfg.get("confidence_threshold", 0.40))
        self.iou_threshold = float(cfg.get("iou_threshold", 0.45))
        self.enabled_fallback = bool(cfg.get("enabled_fallback", True))

        self._model = model_override
        self._is_available = False
        self._status_message = ""

        self._initialize_model()

    def _initialize_model(self) -> None:
        """Attempts to load the custom YOLO model weights or sets fallback."""
        if self._model is not None:
            self._is_available = True
            self._status_message = "Custom ID-card detector initialized (injected/mocked)."
            logger.info(self._status_message)
            return

        if not self.model_path.exists():
            if self.enabled_fallback:
                self._is_available = False
                self._status_message = (
                    f"Custom ID-card weights not found at '{self.model_path}'. "
                    "Running in Fallback Mode: ID-card detection is disabled."
                )
                logger.warning(self._status_message)
                return
            else:
                raise FileNotFoundError(
                    f"Required ID-card detector weights missing at '{self.model_path}' "
                    "and fallback mode is disabled."
                )

        try:
            from ultralytics import YOLO
            self._model = YOLO(str(self.model_path))
            self._is_available = True
            self._status_message = f"Custom ID-card detector loaded successfully from '{self.model_path}'."
            logger.info(self._status_message)
        except Exception as e:
            self._is_available = False
            self._status_message = (
                f"Failed to load ID-card model from '{self.model_path}': {e}. "
                "Operating in fallback mode."
            )
            logger.error(self._status_message)

    @property
    def is_available(self) -> bool:
        """Returns True if trained model weights are successfully loaded."""
        return self._is_available

    @property
    def status_message(self) -> str:
        """User-facing description of detector readiness."""
        return self._status_message

    def detect(self, frame: np.ndarray) -> List[DetectedCard]:
        """
        Runs ID-card detection on a single frame.

        Returns an empty list if the model is not available (fallback mode)
        or if no ID cards are detected above the confidence threshold.
        """
        if not self._is_available or self._model is None:
            return []

        if frame is None or frame.size == 0:
            return []

        detected_cards: List[DetectedCard] = []

        try:
            results = self._model.predict(
                source=frame,
                conf=self.confidence_threshold,
                iou=self.iou_threshold,
                verbose=False,
            )

            if not results or len(results) == 0:
                return []

            boxes = results[0].boxes
            if boxes is None or len(boxes) == 0:
                return []

            card_counter = 1
            for box in boxes:
                xyxy = box.xyxy[0].tolist() if hasattr(box.xyxy, "tolist") else list(box.xyxy[0])
                conf = float(box.conf[0]) if hasattr(box.conf, "__len__") else float(box.conf)

                detected_cards.append(
                    DetectedCard(
                        card_id=card_counter,
                        bbox=BoundingBox(
                            x1=float(xyxy[0]),
                            y1=float(xyxy[1]),
                            x2=float(xyxy[2]),
                            y2=float(xyxy[3]),
                        ),
                        confidence=conf,
                    )
                )
                card_counter += 1

        except Exception as e:
            logger.error("Error during ID card inference: %s", e)
            return []

        return detected_cards
