"""GateID Vision test suite."""
