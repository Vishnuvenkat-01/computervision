"""
GateID Vision — Streamlit Dashboard Application
AI-Based Hostel Gate ID Card Compliance Monitoring System
HackZen 2.0 Hackathon Project
"""
from pathlib import Path
from typing import Any, Dict, List, Optional
import hashlib
import os
import shutil
import sys
import tempfile
import time
import pandas as pd
import streamlit as st

# Ensure project root is in sys.path
PROJECT_ROOT = Path(__file__).resolve().parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from src.config_loader import load_config
from src.cv_compat import HAS_OPENCV
from src.event_capture import CapturedEvent
from src.metrics import calculate_ground_truth_metrics
from src.report_generator import ReportGenerator
from src.video_processor import ProcessingResult, VideoProcessor

# -----------------------------------------------------------------------------
# Streamlit Page Configuration
# -----------------------------------------------------------------------------
st.set_page_config(
    page_title="GateID Vision | Campus Entry Monitoring",
    page_icon="🛡️",
    layout="wide",
    initial_sidebar_state="expanded",
)

# -----------------------------------------------------------------------------
# Custom CSS: Modern Dark Charcoal & Professional Blue Accent Theme
# -----------------------------------------------------------------------------
DARK_THEME_CSS = """
<style>
    /* Global Background and Typography */
    .stApp {
        background-color: #0d1117;
        color: #e6edf3;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
    }

    /* Top Header Banner */
    .app-header {
        background: linear-gradient(135deg, #161b22 0%, #1a2234 100%);
        border: 1px solid #30363d;
        border-radius: 8px;
        padding: 20px 24px;
        margin-bottom: 20px;
    }
    .app-header h1 {
        color: #58a6ff;
        font-size: 26px;
        font-weight: 700;
        margin: 0;
        display: flex;
        align-items: center;
        gap: 10px;
    }
    .app-header p {
        color: #8b949e;
        font-size: 14px;
        margin: 6px 0 0 0;
    }
    .disclaimer-box {
        background-color: #1f293d;
        border-left: 4px solid #388bfd;
        padding: 8px 14px;
        border-radius: 4px;
        font-size: 12.5px;
        color: #c9d1d9;
        margin-top: 12px;
    }

    /* Metric Cards */
    .metric-card {
        background-color: #161b22;
        border: 1px solid #30363d;
        border-radius: 8px;
        padding: 16px 18px;
        box-shadow: 0 2px 4px rgba(0,0,0,0.2);
    }
    .metric-title {
        color: #8b949e;
        font-size: 12px;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        margin-bottom: 6px;
    }
    .metric-value {
        font-size: 28px;
        font-weight: 700;
        color: #f0f6fc;
        margin-bottom: 4px;
    }
    .metric-subtitle {
        font-size: 12px;
        color: #6e7681;
    }

    /* Status Badges */
    .badge-visible {
        background-color: rgba(35, 134, 54, 0.2);
        color: #3fb950;
        border: 1px solid rgba(46, 160, 67, 0.4);
        padding: 3px 8px;
        border-radius: 4px;
        font-weight: 600;
        font-size: 12px;
    }
    .badge-verify {
        background-color: rgba(187, 128, 9, 0.2);
        color: #d29922;
        border: 1px solid rgba(187, 128, 9, 0.4);
        padding: 3px 8px;
        border-radius: 4px;
        font-weight: 600;
        font-size: 12px;
    }
    .badge-uncertain {
        background-color: rgba(137, 87, 229, 0.2);
        color: #bc8cff;
        border: 1px solid rgba(137, 87, 229, 0.4);
        padding: 3px 8px;
        border-radius: 4px;
        font-weight: 600;
        font-size: 12px;
    }

    /* Warning Banner */
    .warning-banner {
        background-color: rgba(187, 128, 9, 0.15);
        border: 1px solid #9e6a03;
        border-radius: 6px;
        padding: 12px 16px;
        margin-bottom: 18px;
        color: #e3b341;
        font-size: 13.5px;
    }

    /* Snapshot Grid Cards */
    .snapshot-card {
        background-color: #161b22;
        border: 1px solid #30363d;
        border-radius: 6px;
        padding: 10px;
        margin-bottom: 12px;
    }

    /* Streamlit overrides for seamless dark aesthetics */
    div[data-testid="stSidebarNav"] {
        display: none;
    }
    .stProgress > div > div > div > div {
        background-color: #388bfd;
    }
</style>
"""
st.markdown(DARK_THEME_CSS, unsafe_allow_html=True)


# -----------------------------------------------------------------------------
# Resource Caching & Helpers
# -----------------------------------------------------------------------------
@st.cache_resource
def get_cached_config() -> Dict[str, Any]:
    """Loads system configuration from config.yaml."""
    cfg_path = PROJECT_ROOT / "config.yaml"
    return load_config(str(cfg_path))


@st.cache_resource
def get_cached_video_processor() -> VideoProcessor:
    """Initializes and caches the VideoProcessor pipeline."""
    config = get_cached_config()
    return VideoProcessor(config=config)


from src.dashboard_utils import check_ultralytics_available, get_file_content_hash


# -----------------------------------------------------------------------------
# Session State Initialization
# -----------------------------------------------------------------------------
def init_session_state() -> None:
    if "current_page" not in st.session_state:
        st.session_state.current_page = "Dashboard"
    if "processed_result" not in st.session_state:
        st.session_state.processed_result = None
    if "last_processed_hash" not in st.session_state:
        st.session_state.last_processed_hash = None
    if "reviewed_cases" not in st.session_state:
        st.session_state.reviewed_cases = {}  # event_id -> review_status
    if "is_processing" not in st.session_state:
        st.session_state.is_processing = False


init_session_state()


# -----------------------------------------------------------------------------
# Top Header Banner
# -----------------------------------------------------------------------------
def render_header() -> None:
    st.markdown(
        """
        <div class="app-header">
            <h1>🛡️ GateID Vision</h1>
            <p><strong>AI-Based Hostel Gate ID Card Compliance Monitoring System</strong> (Crowd-Aware Decision Support)</p>
            <div class="disclaimer-box">
                ℹ️ <strong>System Notice:</strong> This system assists hostel security personnel by identifying cases that require manual verification. It does not verify personal identity or the authenticity of ID cards.
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )


# -----------------------------------------------------------------------------
# Model Status Warning (If Custom Detector is Absent)
# -----------------------------------------------------------------------------
def render_model_warning_if_needed(processor: VideoProcessor) -> None:
    if not processor.id_detector.is_available:
        st.markdown(
            """
            <div class="warning-banner">
                ⚠️ <strong>ID-Card Detector Fallback Active:</strong>
                Custom model weights were not found at <code>models/id_card_detector.pt</code>.
                The system is operating in <strong>Person Tracking Mode</strong>. All card-dependent compliance
                statuses default to <em>Uncertain</em>. The system will NOT fabricate ID-card detections or claim
                that an ID card is missing.
            </div>
            """,
            unsafe_allow_html=True,
        )


# -----------------------------------------------------------------------------
# Sidebar Navigation
# -----------------------------------------------------------------------------
def render_sidebar(processor: VideoProcessor) -> str:
    st.sidebar.markdown("### 🏛️ Navigation")
    pages = [
        ("📊 Dashboard", "Dashboard"),
        ("📹 Video Monitoring", "Video Monitoring"),
        ("🔍 Verification Queue", "Verification Queue"),
        ("📜 Event History", "Event History"),
        ("📑 Reports", "Reports"),
        ("⚙️ System Status", "System Status"),
    ]

    for label, key in pages:
        is_active = (st.session_state.current_page == key)
        button_type = "primary" if is_active else "secondary"
        if st.sidebar.button(label, key=f"nav_{key}", use_container_width=True, type=button_type):
            st.session_state.current_page = key
            st.rerun()

    st.sidebar.markdown("---")
    st.sidebar.markdown("### ⚙️ Pipeline Quick Status")

    # Status indicators in sidebar
    model_ok = processor.id_detector.is_available
    cv_ok = HAS_OPENCV
    ultra_ok = check_ultralytics_available()

    st.sidebar.markdown(f"**OpenCV:** {'🟢 Active' if cv_ok else '🟡 Fallback Shim'}")
    st.sidebar.markdown(f"**Ultralytics:** {'🟢 Loaded' if ultra_ok else '🟡 Not Installed'}")
    st.sidebar.markdown(f"**ID Detector:** {'🟢 Loaded' if model_ok else '🟠 Fallback (Missing)'}")

    if st.session_state.processed_result is not None:
        st.sidebar.markdown("---")
        st.sidebar.markdown("### 📁 Active Result")
        res = st.session_state.processed_result
        st.sidebar.caption(f"Video: `{Path(res.video_path).name}`")
        st.sidebar.caption(f"Tracked People: **{res.metrics.unique_tracked_people}**")
        st.sidebar.caption(f"Events: **{res.metrics.total_events_captured}**")
        if st.sidebar.button("🗑️ Clear Active Result", use_container_width=True):
            st.session_state.processed_result = None
            st.session_state.last_processed_hash = None
            st.rerun()

    st.sidebar.markdown("---")
    st.sidebar.caption("HackZen 2.0 • GateID Vision v1.0.0")
    return st.session_state.current_page


# -----------------------------------------------------------------------------
# 1. Dashboard Overview Page
# -----------------------------------------------------------------------------
def render_dashboard_page(processor: VideoProcessor) -> None:
    st.markdown("## 📊 Dashboard Overview")
    render_model_warning_if_needed(processor)

    res: Optional[ProcessingResult] = st.session_state.processed_result

    # Metric Row
    c1, c2, c3, c4, c5, c6 = st.columns(6)

    with c1:
        val = str(res.metrics.unique_tracked_people) if res else "N/A"
        st.markdown(
            f"""
            <div class="metric-card">
                <div class="metric-title">Tracked People</div>
                <div class="metric-value">{val}</div>
                <div class="metric-subtitle">Unique Visitors</div>
            </div>
            """,
            unsafe_allow_html=True,
        )

    with c2:
        val = str(res.metrics.id_visible_count) if res else "N/A"
        st.markdown(
            f"""
            <div class="metric-card">
                <div class="metric-title">ID Visible</div>
                <div class="metric-value" style="color:#3fb950;">{val}</div>
                <div class="metric-subtitle">Confirmed Badges</div>
            </div>
            """,
            unsafe_allow_html=True,
        )

    with c3:
        val = str(res.metrics.verification_required_count) if res else "N/A"
        st.markdown(
            f"""
            <div class="metric-card">
                <div class="metric-title">Needs Verify</div>
                <div class="metric-value" style="color:#d29922;">{val}</div>
                <div class="metric-subtitle">Review Prompts</div>
            </div>
            """,
            unsafe_allow_html=True,
        )

    with c4:
        val = str(res.metrics.uncertain_count) if res else "N/A"
        st.markdown(
            f"""
            <div class="metric-card">
                <div class="metric-title">Uncertain Cases</div>
                <div class="metric-value" style="color:#bc8cff;">{val}</div>
                <div class="metric-subtitle">Occluded / Blurred</div>
            </div>
            """,
            unsafe_allow_html=True,
        )

    with c5:
        val = f"{res.elapsed_time_sec:.1f}s" if res else "N/A"
        st.markdown(
            f"""
            <div class="metric-card">
                <div class="metric-title">Process Time</div>
                <div class="metric-value">{val}</div>
                <div class="metric-subtitle">Elapsed Duration</div>
            </div>
            """,
            unsafe_allow_html=True,
        )

    with c6:
        val = f"{res.metrics.approx_fps:.1f}" if res and res.metrics.approx_fps > 0 else "N/A"
        st.markdown(
            f"""
            <div class="metric-card">
                <div class="metric-title">Throughput</div>
                <div class="metric-value">{val}</div>
                <div class="metric-subtitle">Effective FPS</div>
            </div>
            """,
            unsafe_allow_html=True,
        )

    st.markdown("<br>", unsafe_allow_html=True)

    if not res:
        st.info("ℹ️ **No video analyzed yet.** Navigate to **Video Monitoring** to upload and automatically analyze a gate entry recording.")
        return

    # Charts and Event Breakdown
    col_chart, col_events = st.columns([1, 1])

    with col_chart:
        st.markdown("### 📈 Classification Breakdown")
        m = res.metrics
        status_data = pd.DataFrame(
            {
                "Category": ["ID Visible", "Verification Required", "Uncertain"],
                "Count": [m.id_visible_count, m.verification_required_count, m.uncertain_count],
            }
        ).set_index("Category")

        if m.total_events_captured > 0:
            st.bar_chart(status_data, color="#388bfd", height=280)
        else:
            st.caption("No events recorded during video analysis.")

    with col_events:
        st.markdown("### 🕒 Recent Monitoring Events")
        events = res.events
        if events:
            recent_events = events[-5:]
            for e in reversed(recent_events):
                badge_class = (
                    "badge-visible"
                    if e.status == "id_visible"
                    else ("badge-verify" if e.status == "verification_required" else "badge-uncertain")
                )
                st.markdown(
                    f"""
                    <div style="background:#161b22; border:1px solid #30363d; border-radius:6px; padding:8px 12px; margin-bottom:8px;">
                        <span class="{badge_class}">{e.status.upper()}</span>
                        <strong> Track {e.track_id}</strong> &nbsp;
                        <span style="color:#8b949e; font-size:12px;">t={e.video_timestamp}s (Frame {e.frame_number})</span><br>
                        <small style="color:#c9d1d9;">{e.reason}</small>
                    </div>
                    """,
                    unsafe_allow_html=True,
                )
        else:
            st.caption("No event flags were captured for this video.")

    # Recent Snapshot Previews
    st.markdown("### 📸 Captured Evidence Previews")
    snap_events = [e for e in res.events if e.snapshot_path and Path(e.snapshot_path).exists()]
    if snap_events:
        cols = st.columns(min(4, len(snap_events)))
        for idx, e in enumerate(snap_events[:4]):
            with cols[idx]:
                st.image(e.snapshot_path, caption=f"Track {e.track_id} | {e.status}", use_container_width=True)
    else:
        st.caption("No snapshot image files available on disk for preview.")


# -----------------------------------------------------------------------------
# 2. Video Monitoring Page (Primary Feature with Auto-Run on Upload)
# -----------------------------------------------------------------------------
def render_video_monitoring_page(processor: VideoProcessor) -> None:
    st.markdown("## 📹 Video Monitoring")
    render_model_warning_if_needed(processor)

    st.markdown(
        """
        Upload a recorded college gate or hostel entrance video file.
        **The pipeline will automatically trigger monitoring upon upload.**
        """
    )

    uploaded_file = st.file_uploader(
        "Choose an entrance recording (MP4, AVI, MOV, MKV)",
        type=["mp4", "avi", "mov", "mkv"],
        help="Upload recorded video of students entering the gate.",
    )

    if uploaded_file is None:
        st.info("👋 Upload a recorded video above to start automatic compliance monitoring.")
        if st.session_state.processed_result is not None:
            st.markdown("---")
            st.markdown("#### Previously Processed Video Results:")
            _render_processed_video_view(st.session_state.processed_result)
        return

    # File details
    file_bytes = uploaded_file.getvalue()
    file_size_mb = len(file_bytes) / (1024 * 1024)
    file_hash = get_file_content_hash(file_bytes)

    col_meta1, col_meta2, col_meta3 = st.columns(3)
    col_meta1.caption(f"**Filename:** `{uploaded_file.name}`")
    col_meta2.caption(f"**Size:** `{file_size_mb:.2f} MB`")
    col_meta3.caption(f"**Hash:** `{file_hash[:10]}...`")

    # Check if this exact file was already processed to prevent duplicate processing on rerun
    already_processed = (
        st.session_state.processed_result is not None
        and st.session_state.last_processed_hash == file_hash
    )

    col_btn1, col_btn2 = st.columns([1, 4])
    with col_btn1:
        reprocess = st.button("🔄 Re-process Video", help="Force re-run the pipeline on this video")

    if not already_processed or reprocess:
        # Save uploaded video to temporary staging location
        temp_dir = Path("data/staging")
        temp_dir.mkdir(parents=True, exist_ok=True)
        temp_video_path = temp_dir / f"upload_{file_hash[:8]}_{uploaded_file.name}"

        with open(temp_video_path, "wb") as f:
            f.write(file_bytes)

        st.markdown("### ⚡ Automatic Video Analysis in Progress")
        progress_bar = st.progress(0.0)
        status_text = st.empty()
        preview_container = st.empty()
        metrics_container = st.empty()

        def on_progress(ratio: float, cur_frame: int, total_frames: int, frame_arr: Any, stats: Dict[str, Any]):
            progress_bar.progress(min(1.0, max(0.0, ratio)))
            status_text.markdown(f"**Processing Frame:** `{cur_frame} / {total_frames}` ({ratio*100:.1f}%)")
            metrics_container.markdown(
                f"**Active People in View:** `{stats.get('active_people', 0)}` | "
                f"**Unique Visitors Tracked:** `{stats.get('unique_people', 0)}` | "
                f"**Events Captured:** `{stats.get('total_events', 0)}`"
            )
            # Display real-time video frame preview
            if frame_arr is not None and hasattr(frame_arr, "shape") and frame_arr.size > 0:
                try:
                    preview_container.image(frame_arr, channels="BGR", caption="Live Pipeline View", use_container_width=True)
                except Exception:
                    pass

        try:
            with st.spinner("Executing Computer Vision Pipeline..."):
                result = processor.process_video(
                    video_path=str(temp_video_path),
                    progress_callback=on_progress,
                )

            st.session_state.processed_result = result
            st.session_state.last_processed_hash = file_hash
            st.success("✅ Video processing and compliance monitoring completed successfully!")
            st.rerun()

        except Exception as e:
            st.error(f"❌ Processing failed with an error: {e}")
            return
        finally:
            # Clean up temp file
            if temp_video_path.exists():
                try:
                    temp_video_path.unlink()
                except Exception:
                    pass

    else:
        # Display results of already processed video
        st.markdown("### 📋 Analysis Results")
        _render_processed_video_view(st.session_state.processed_result)


def _render_processed_video_view(res: ProcessingResult) -> None:
    """Helper to render the processed video preview and summary cards."""
    col_v, col_s = st.columns([3, 2])

    with col_v:
        st.markdown("#### 🎬 Annotated Output Video")
        if res.output_video_path and Path(res.output_video_path).exists():
            v_path = Path(res.output_video_path)
            # Video player
            try:
                st.video(str(v_path))
            except Exception:
                st.info("Video format cannot be played inline by the browser, but it is available for download below.")

            with open(v_path, "rb") as vf:
                st.download_button(
                    label="⬇️ Download Annotated Video (MP4)",
                    data=vf.read(),
                    file_name=v_path.name,
                    mime="video/mp4",
                    use_container_width=True,
                )
        else:
            st.warning("Annotated output video file is not available.")

    with col_s:
        st.markdown("#### 📊 Processing Summary")
        m = res.metrics
        st.markdown(f"- **Input File:** `{Path(res.video_path).name}`")
        st.markdown(f"- **Total Frames:** `{res.total_frames}` (Processed: `{res.processed_frames}`)")
        st.markdown(f"- **Elapsed Time:** `{res.elapsed_time_sec:.2f} s`")
        st.markdown(f"- **Processing Speed:** `{m.approx_fps:.2f} FPS`")
        st.markdown(f"- **Unique Tracked People:** `{m.unique_tracked_people}`")
        st.markdown(f"- **ID Visible Detections:** `{m.id_visible_count}`")
        st.markdown(f"- **Verification Required:** `{m.verification_required_count}`")
        st.markdown(f"- **Uncertain Observations:** `{m.uncertain_count}`")

        if res.report_csv_path and Path(res.report_csv_path).exists():
            with open(res.report_csv_path, "rb") as cf:
                st.download_button(
                    label="📄 Download Event Report (CSV)",
                    data=cf.read(),
                    file_name=Path(res.report_csv_path).name,
                    mime="text/csv",
                    use_container_width=True,
                )


# -----------------------------------------------------------------------------
# 3. Verification Queue Page
# -----------------------------------------------------------------------------
def render_verification_queue_page(processor: VideoProcessor) -> None:
    st.markdown("## 🔍 Verification Queue")
    render_model_warning_if_needed(processor)

    st.markdown(
        """
        Cases requiring **manual security officer inspection**.
        Flagged observations are recommendations for manual verification,
        **not proof of an unbadged student or disciplinary violation**.
        """
    )

    res: Optional[ProcessingResult] = st.session_state.processed_result
    if not res or not res.events:
        st.info("No cases currently in the verification queue. Process a video in **Video Monitoring** to populate cases.")
        return

    # Filter controls
    f_col1, f_col2 = st.columns([2, 1])
    with f_col1:
        status_filter = st.multiselect(
            "Filter by Status:",
            options=["verification_required", "uncertain", "id_visible"],
            default=["verification_required", "uncertain"],
        )
    with f_col2:
        search_query = st.text_input("Search by Track ID or Reason:", "")

    filtered_events = [
        e for e in res.events
        if e.status in status_filter
        and (search_query.lower() in str(e.track_id) or search_query.lower() in e.reason.lower())
    ]

    st.markdown(f"**Showing {len(filtered_events)} case(s)**")

    if not filtered_events:
        st.caption("No events matched the chosen filters.")
        return

    for evt in filtered_events:
        card_class = (
            "badge-verify"
            if evt.status == "verification_required"
            else ("badge-uncertain" if evt.status == "uncertain" else "badge-visible")
        )
        reviewed_status = st.session_state.reviewed_cases.get(evt.event_id, "Pending Review")

        with st.container():
            st.markdown(
                f"""
                <div style="background:#161b22; border:1px solid #30363d; border-radius:8px; padding:14px; margin-bottom:14px;">
                    <div style="display:flex; justify-content:space-between; align-items:center;">
                        <div>
                            <span class="{card_class}">{evt.status.upper()}</span> &nbsp;
                            <strong>Track ID: Person {evt.track_id}</strong> &nbsp;
                            <span style="color:#8b949e; font-size:12px;">Event: {evt.event_id}</span>
                        </div>
                        <div style="font-size:12px; color:{'#3fb950' if reviewed_status != 'Pending Review' else '#d29922'};">
                            <strong>Status:</strong> {reviewed_status}
                        </div>
                    </div>
                    <div style="margin-top:8px; font-size:13px; color:#c9d1d9;">
                        <strong>Reason:</strong> {evt.reason} <br>
                        <strong>Timestamp:</strong> {evt.video_timestamp}s (Frame {evt.frame_number}) |
                        <strong>Person Conf:</strong> {evt.person_confidence:.1%} |
                        <strong>Association:</strong> {evt.association_outcome}
                    </div>
                </div>
                """,
                unsafe_allow_html=True,
            )

            col_img, col_act = st.columns([2, 1])
            with col_img:
                if evt.snapshot_path and Path(evt.snapshot_path).exists():
                    st.image(evt.snapshot_path, caption=f"Snapshot (Track {evt.track_id})", use_container_width=True)
                else:
                    st.caption("Snapshot preview not stored on disk.")

            with col_act:
                st.markdown("##### Officer Action:")
                if st.button("✅ Confirm ID Physically", key=f"rev_ok_{evt.event_id}"):
                    st.session_state.reviewed_cases[evt.event_id] = "Manually Verified (ID Present)"
                    st.rerun()
                if st.button("⚠️ Manual Check Required", key=f"rev_warn_{evt.event_id}"):
                    st.session_state.reviewed_cases[evt.event_id] = "Flagged for Physical Check"
                    st.rerun()
                if st.button("❌ Dismiss Observation", key=f"rev_dis_{evt.event_id}"):
                    st.session_state.reviewed_cases[evt.event_id] = "Dismissed by Officer"
                    st.rerun()


# -----------------------------------------------------------------------------
# 4. Event History Page
# -----------------------------------------------------------------------------
def render_event_history_page(processor: VideoProcessor) -> None:
    st.markdown("## 📜 Event History")
    render_model_warning_if_needed(processor)

    res: Optional[ProcessingResult] = st.session_state.processed_result
    if not res or not res.events:
        st.info("No monitoring history recorded yet. Process a video in **Video Monitoring** to log events.")
        return

    report_gen = ReportGenerator()
    df = report_gen.events_to_dataframe(res.events)

    # Attach human review outcomes if any
    if "manual_review_outcome" in df.columns:
        df["manual_review_outcome"] = df["event_id"].apply(
            lambda eid: st.session_state.reviewed_cases.get(eid, "Pending Review")
        )

    # Controls
    c1, c2 = st.columns([1, 1])
    with c1:
        sel_status = st.multiselect(
            "Filter by Status:",
            options=list(df["status"].unique()),
            default=list(df["status"].unique()),
        )
    with c2:
        sort_by = st.selectbox("Sort Table by:", ["video_timestamp", "track_id", "frame_number"])

    df_filtered = df[df["status"].isin(sel_status)].sort_values(by=sort_by)

    st.markdown(f"**Total Records:** `{len(df_filtered)}`")
    st.dataframe(df_filtered, use_container_width=True)

    # Snapshot inspection
    st.markdown("### 🖼️ Inspect Snapshot by Event ID")
    event_ids = list(df_filtered["event_id"].unique())
    if event_ids:
        selected_eid = st.selectbox("Select Event ID:", event_ids)
        matched_evt = next((e for e in res.events if e.event_id == selected_eid), None)
        if matched_evt and matched_evt.snapshot_path and Path(matched_evt.snapshot_path).exists():
            st.image(
                matched_evt.snapshot_path,
                caption=f"{matched_evt.event_id} | Track {matched_evt.track_id} | {matched_evt.status}",
                width=500,
            )
        else:
            st.caption("No snapshot image file found for this event.")


# -----------------------------------------------------------------------------
# 5. Reports Page
# -----------------------------------------------------------------------------
def render_reports_page(processor: VideoProcessor) -> None:
    st.markdown("## 📑 Compliance & Audit Reports")
    render_model_warning_if_needed(processor)

    res: Optional[ProcessingResult] = st.session_state.processed_result
    if not res:
        st.info("No report data available. Analyze a video to generate audit reports.")
        return

    m = res.metrics
    report_gen = ReportGenerator()
    df = report_gen.events_to_dataframe(res.events)

    # Attach human review outcomes
    if "manual_review_outcome" in df.columns:
        df["manual_review_outcome"] = df["event_id"].apply(
            lambda eid: st.session_state.reviewed_cases.get(eid, "Pending Review")
        )

    st.markdown("### 📊 Operational Summary")
    s_col1, s_col2, s_col3 = st.columns(3)
    s_col1.metric("Unique Visitors Tracked", m.unique_tracked_people)
    s_col2.metric("Total Capture Events", m.total_events_captured)
    s_col3.metric("Processing Throughput", f"{m.approx_fps:.1f} FPS")

    # Honest Ground-Truth Notice
    st.markdown("### 🎯 Ground-Truth Evaluation Metrics")
    gt_eval = calculate_ground_truth_metrics(predictions=[], ground_truth=[])
    st.markdown(
        f"""
        <div style="background:#161b22; border:1px solid #30363d; border-radius:6px; padding:12px; font-size:13px;">
            <strong>Evaluation Status:</strong> <code>{gt_eval['status'].upper()}</code><br>
            <em>{gt_eval['message']}</em><br>
            Operational detection counts represent live observed flags, not verified test accuracy percentages.
            Precision, Recall, and F1 require manually annotated ground-truth boxes.
        </div>
        """,
        unsafe_allow_html=True,
    )

    st.markdown("### 📥 Export Reports & Video")
    csv_bytes = df.to_csv(index=False).encode("utf-8")
    d_col1, d_col2 = st.columns(2)

    with d_col1:
        st.download_button(
            label="⬇️ Download Event Audit Report (CSV)",
            data=csv_bytes,
            file_name=f"gateid_report_{Path(res.video_path).stem}.csv",
            mime="text/csv",
            use_container_width=True,
        )

    with d_col2:
        if res.output_video_path and Path(res.output_video_path).exists():
            with open(res.output_video_path, "rb") as vf:
                st.download_button(
                    label="⬇️ Download Annotated Video (MP4)",
                    data=vf.read(),
                    file_name=Path(res.output_video_path).name,
                    mime="video/mp4",
                    use_container_width=True,
                )
        else:
            st.button("Annotated Video Unavailable", disabled=True, use_container_width=True)

    st.markdown("### 📋 Event Data Preview")
    st.dataframe(df, use_container_width=True)


# -----------------------------------------------------------------------------
# 6. System Status Page
# -----------------------------------------------------------------------------
def render_system_status_page(processor: VideoProcessor) -> None:
    st.markdown("## ⚙️ System Status & Hardware Environment")

    config = get_cached_config()

    col_env, col_mod = st.columns(2)

    with col_env:
        st.markdown("### 🖥️ Environment & Dependencies")
        cv_active = HAS_OPENCV
        ultra_active = check_ultralytics_available()

        st.markdown(f"- **Python Version:** `{sys.version.split()[0]}`")
        st.markdown(f"- **Streamlit Version:** `{st.__version__}`")
        st.markdown(
            f"- **OpenCV (cv2):** {'🟢 Native OpenCV Active' if cv_active else '🟡 Fallback Shim Active (opencv-python not found)'}"
        )
        st.markdown(
            f"- **Ultralytics YOLO:** {'🟢 Ultralytics Library Loaded' if ultra_active else '🟡 Not Installed in Active Environment'}"
        )
        st.markdown(f"- **System Platform:** `{sys.platform}`")
        st.markdown(f"- **Config Loaded:** `config.yaml` (v{config.get('system', {}).get('version', '1.0.0')})")

        if not cv_active:
            st.caption("ℹ️ *Notice: Fallback shim is provided for unit testing and CI. For production native video decoding, run `pip install -r requirements.txt`.*")

    with col_mod:
        st.markdown("### 🧠 Model Weights & Detector Status")
        person_cfg = config.get("models", {}).get("person_detector", {})
        id_cfg = config.get("models", {}).get("id_card_detector", {})

        st.markdown(f"- **Person Detector:** `{person_cfg.get('model_name', 'yolov8n.pt')}`")
        st.markdown(f"- **Person Conf Threshold:** `{person_cfg.get('confidence_threshold', 0.45)}`")
        st.markdown(f"- **Tracker Type:** `{person_cfg.get('tracker_type', 'bytetrack.yaml')}`")

        id_path = Path(id_cfg.get("model_path", "models/id_card_detector.pt"))
        id_exists = id_path.exists()
        st.markdown(f"- **ID-Card Detector Path:** `{id_path}`")
        st.markdown(
            f"- **ID-Card Detector Status:** {'🟢 Model Weights Present' if id_exists else '🟠 Model Weights Missing (Fallback Mode Active)'}"
        )
        st.markdown(f"- **Fallback Mode Enabled:** `{id_cfg.get('enabled_fallback', True)}`")

    st.markdown("### 📁 Output Directories Health")
    dirs = [
        ("Snapshots Directory", Path("outputs/snapshots")),
        ("Reports Directory", Path("outputs/reports")),
        ("Processed Videos Directory", Path("outputs/processed_videos")),
    ]
    d_cols = st.columns(3)
    for idx, (label, p) in enumerate(dirs):
        exists = p.exists()
        d_cols[idx].markdown(
            f"""
            <div style="background:#161b22; border:1px solid #30363d; border-radius:6px; padding:10px;">
                <strong>{label}</strong><br>
                <code>{p}</code><br>
                <span style="color:{'#3fb950' if exists else '#f85149'}; font-size:12px;">
                    {'Accessible & Ready' if exists else 'Missing Directory'}
                </span>
            </div>
            """,
            unsafe_allow_html=True,
        )


# -----------------------------------------------------------------------------
# Main Application Router
# -----------------------------------------------------------------------------
def main() -> None:
    render_header()
    processor = get_cached_video_processor()
    current_page = render_sidebar(processor)

    if current_page == "Dashboard":
        render_dashboard_page(processor)
    elif current_page == "Video Monitoring":
        render_video_monitoring_page(processor)
    elif current_page == "Verification Queue":
        render_verification_queue_page(processor)
    elif current_page == "Event History":
        render_event_history_page(processor)
    elif current_page == "Reports":
        render_reports_page(processor)
    elif current_page == "System Status":
        render_system_status_page(processor)
    else:
        render_dashboard_page(processor)


if __name__ == "__main__":
    main()
